

<?php echo "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n"; ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/tr/xhtml1/DTD/xhtml11.dtd" >
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en-gb">
<head></head>
    
    <body>
    
    <?php
$host    = 'mysql.cms.gre.ac.uk';
$user    = 'sm2418r';
$passwd  = 'sm2418r';
$dbName  = 'mdb_sm2418r';
?>
    </body>
</html>