<!-- FOOTER -->
    <footer class="bg-dark text-white">
      <div class="container">
        <div class="row">
          <div class="col">
          <p class="lead text-center">GucciGang | Enterprise | <span id="year"></span> &copy; All rights Reserved.</p>
          <p class="text-center small"><a style="color: white; text-decoration: none; cursor: pointer;"> Enterprise Groupwork Produced By <br>Sudhakar Maharaj (000533369), Shaun Miah (000890936), Shayne (001044667), Fayyaadh Akuji (000931277), Juber Ali (000881522)<br> Reebal Mohammed Shah & Jesumudiamen Ayela-Uwangue (000910107) 
</a></p>
           </div>
         </div>
      </div>
    </footer>
        <div style="height:10px; background:#27aae1;"></div>
    <!-- FOOTER END-->



