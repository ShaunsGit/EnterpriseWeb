<?php
$fp = fopen("ORDERS/order.xml", "w") or die("Couldn't create new file");
?>